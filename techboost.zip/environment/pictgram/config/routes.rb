Rails.application.routes.draw do
  get 'pages/link'
  root 'pages#link'
  
  get 'pages/index'
  root 'pages#index'
  
  get 'pages/help'
  root 'pages#help'
end
